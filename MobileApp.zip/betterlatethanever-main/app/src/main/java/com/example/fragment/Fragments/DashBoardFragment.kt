package com.example.fragment.Fragments

import androidx.fragment.app.Fragment
import com.example.fragment.R

class DashBoardFragment : Fragment(R.layout.fragment_dashboard) {
}